 console.log(__dirname);
